"""Phase contract configuration loading and resolution."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mcp_server.core.exceptions import ConfigError
from mcp_server.core.interfaces.project_plan import IProjectPlanReader
from mcp_server.schemas import (
    BranchLocalArtifact,
    CheckSpec,
    ContractsConfig,
    WorkphasesConfig,
)

_PHASE_CONTRACTS_DISPLAY_PATH = "config/contracts.yaml"
_WORKPHASES_DISPLAY_PATH = "config/workphases.yaml"


def _is_dict(value: object) -> bool:
    """Check runtime containers without refining the public dynamic plan contract."""
    return isinstance(value, dict)


@dataclass(frozen=True)
class MergeReadinessContext:
    """Facade bundling merge-readiness data for EnforcementRunner handlers.

    Constructed once at server startup from the loaded config objects.
    Handlers read current_phase at execution time from StateRepository.
    """

    terminal_phase: str  # from WorkphasesConfig.get_terminal_phase()
    pr_allowed_phase: str  # from ContractsConfig.get_pr_allowed_phase()
    branch_local_artifacts: tuple[BranchLocalArtifact, ...]  # from ContractsConfig


@dataclass(frozen=True)
class PhaseConfigContext:
    """Facade bundling immutable workflow configuration."""

    workphases: WorkphasesConfig
    contracts: ContractsConfig


class PhaseContractResolver:
    """Resolve workflow-phase contracts into concrete check specs."""

    def __init__(self, config: PhaseConfigContext, project_plan_reader: IProjectPlanReader) -> None:
        self._config = config
        self._project_plan_reader = project_plan_reader

    def is_cycle_based_phase(self, workflow_name: str, phase: str) -> bool:
        """Report whether one workflow phase is marked cycle_based in config."""
        workflow_entry = self._config.contracts.workflows.get(workflow_name)
        if workflow_entry is None:
            return False

        try:
            phase_entry = workflow_entry.get_phase(phase)
        except ValueError:
            return False

        return phase_entry.cycle_based

    def resolve_commit_type(
        self,
        workflow_name: str,
        phase: str,
        sub_phase: str | None,
    ) -> str | None:
        """Resolve commit type from phase contracts for one workflow phase."""
        workflow_entry = self._config.contracts.workflows.get(workflow_name)
        if workflow_entry is None:
            return None

        try:
            phase_entry = workflow_entry.get_phase(phase)
        except ValueError:
            return None

        if sub_phase is None:
            return None

        if sub_phase not in phase_entry.commit_type_map:
            raise ConfigError(
                (
                    f"Missing commit_type_map entry for sub_phase '{sub_phase}' "
                    f"in workflow '{workflow_name}' phase '{phase}'"
                ),
                file_path=_PHASE_CONTRACTS_DISPLAY_PATH,
            )

        return phase_entry.commit_type_map[sub_phase]

    def resolve_phase_exit(
        self,
        workflow_name: str,
        phase: str,
        cycle_number: int | None = None,
        *,
        issue_number: int,
    ) -> list[CheckSpec]:
        """Resolve phase-exit checks: exit_requires + cycle_exit_requires[cycle_number] if present.

        Use for phase transitions. Includes both the phase-level required gates and,
        when cycle_number is given, the cycle-level gates for that cycle.
        """
        workflow_entry = self._config.contracts.workflows.get(workflow_name)
        if workflow_entry is None:
            return []

        try:
            phase_entry = workflow_entry.get_phase(phase)
        except ValueError:
            return []

        config_checks = [
            CheckSpec(id=key, **requirement.model_dump(exclude={"order"}))
            for key, requirement in phase_entry.exit_requires.items()
        ]
        if cycle_number is not None:
            config_checks.extend(
                CheckSpec(id=key, **requirement.model_dump(exclude={"order"}))
                for key, requirement in phase_entry.cycle_exit_requires.get(
                    cycle_number, {}
                ).items()
            )

        issue_checks = self._resolve_issue_checks(
            workflow_name=workflow_name,
            phase=phase,
            cycle_number=cycle_number,
            issue_number=issue_number,
        )
        return self._merge_checks(config_checks=config_checks, issue_checks=issue_checks)

    def resolve_cycle_exit(
        self,
        workflow_name: str,
        phase: str,
        cycle_number: int,
        *,
        issue_number: int,
    ) -> list[CheckSpec]:
        """Resolve cycle-exit checks: cycle_exit_requires[cycle_number] only.

        Use for cycle transitions. Excludes phase-level exit_requires so that gates
        that belong only to phase transitions are not enforced during cycle advancement.
        """
        workflow_entry = self._config.contracts.workflows.get(workflow_name)
        if workflow_entry is None:
            return []

        try:
            phase_entry = workflow_entry.get_phase(phase)
        except ValueError:
            return []

        config_checks = [
            CheckSpec(id=key, **requirement.model_dump(exclude={"order"}))
            for key, requirement in phase_entry.cycle_exit_requires.get(cycle_number, {}).items()
        ]

        issue_checks = self._resolve_issue_checks(
            workflow_name=workflow_name,
            phase=phase,
            cycle_number=cycle_number,
            issue_number=issue_number,
        )
        return self._merge_checks(config_checks=config_checks, issue_checks=issue_checks)

    def _resolve_issue_checks(
        self,
        workflow_name: str,
        phase: str,
        cycle_number: int | None,
        issue_number: int,
    ) -> list[CheckSpec]:
        """Resolve issue-specific checks from deliverables.json for the active phase."""
        project = self._project_plan_reader.get_project_plan(issue_number)
        if project is None:
            raise ValueError(f"Project {issue_number} not found. Initialize project first.")
        planning_deliverables = project.get("planning_deliverables")
        if planning_deliverables is None:
            return []

        deliverables: list[dict[str, Any]] = []
        if self.is_cycle_based_phase(workflow_name, phase) and cycle_number is not None:
            cycles_data = planning_deliverables.get("cycles", {})
            cycles = cycles_data.get("cycles", [])
            matching_cycle = next(
                (
                    cycle
                    for cycle in cycles
                    if _is_dict(cycle) and cycle.get("cycle_number") == cycle_number
                ),
                None,
            )
            if matching_cycle is not None and _is_dict(matching_cycle):
                deliverables = matching_cycle.get("deliverables", [])
        else:
            phase_data = planning_deliverables.get("phases", {}).get(phase, {})
            if _is_dict(phase_data):
                deliverables = phase_data.get("deliverables", [])

        resolved_issue_checks: list[CheckSpec] = []
        for deliverable in deliverables:
            if not _is_dict(deliverable):
                continue
            validates = deliverable.get("validates")
            if validates is None or not _is_dict(validates):
                continue
            issue_check_payload = {
                "id": str(deliverable.get("deliverable_id", "issue-check")),
                "required": False,
                **validates,
            }
            resolved_issue_checks.append(CheckSpec.model_validate(issue_check_payload))

        return resolved_issue_checks

    def _merge_checks(
        self,
        config_checks: list[CheckSpec],
        issue_checks: list[CheckSpec],
    ) -> list[CheckSpec]:
        """Apply A6 merge semantics for config and issue-specific gates."""
        required_checks = [check for check in config_checks if check.required]
        required_ids = {check.id for check in required_checks}

        recommended_checks = [check for check in config_checks if not check.required]
        merged_recommended: dict[str, CheckSpec] = {check.id: check for check in recommended_checks}
        recommended_order = [check.id for check in recommended_checks]

        for issue_check in issue_checks:
            if issue_check.id in required_ids:
                continue
            if issue_check.id not in merged_recommended:
                recommended_order.append(issue_check.id)
            merged_recommended[issue_check.id] = issue_check

        return [
            *required_checks,
            *(merged_recommended[check_id] for check_id in recommended_order),
        ]
