# PhaseGate MCP Server - Resources Specification

**Status:** v1.0 (Foundation)
**Last Updated:** 2026-10-18

---

## 1. Resources

Resources expose read-only data through MCP URIs. This reference distinguishes proposed resources from those currently registered; a section marked **Planned** is not an available endpoint. Current tool-result resources include `pgmcp://cache/runs/{run_id}`, and policy discovery is provided by `pgmcp://rules/coding_standards`. Resource content is not evidence that a check or test passed unless it explicitly contains that operation's result.

---

### Resource Transport

The central server handler returns an explicit MCP SDK `ReadResourceResult`
containing `TextResourceContents` with `text/plain` content, preserving the requested
URI in the MCP response.
A payload described below as JSON is serialized JSON text; its data format does not
change that transport media type. Unknown URIs and resource-read failures remain
errors. The wrapper does not change resource matching, payloads or cache lifetime.

See the [server boundary](../../mcp_server/server.py) and
[dependency declarations](../../pyproject.toml). Embedded schema attachments in
tool responses have their own media type and serialization owner; see
[Presentation Architecture](presentation_architecture.md#ownership-boundaries).

---

### 1.1 `pgmcp://status/implementation` (Planned)

**Description:** Live view of project implementation status, test counts, and module completion metrics. Parsed from `docs/implementation/IMPLEMENTATION_STATUS.md`.

**Data Format:** `json`

**Refresh Trigger:** File watcher on `docs/implementation/IMPLEMENTATION_STATUS.md`

```yaml
schema:
  type: object
  properties:
    last_updated:
      type: string
      format: date
      description: "Date the status doc was last updated"
    quick_status:
      type: string
      description: "Optional evidence-backed summary; do not infer a pass from configured policy."
    summary_table:
      type: array
      description: "Layer-by-layer breakdown"
      items:
        type: object
        properties:
          layer: { type: string, examples: ["Strategy DTOs", "Shared DTOs", "Core Services"] }
          tests_passing: { type: [integer, "null"] }
          tests_total: { type: [integer, "null"] }
          status: { type: string, enum: ["✅ Complete", "🔄 In Progress", "🔴 Not Started"] }
    recent_updates:
      type: array
      description: "Last 5 significant changes"
      items:
        type: object
        properties:
          date: { type: string, format: date }
          description: { type: string }
          commit_hash: { type: string }
    technical_debt:
      type: object
      properties:
        open_items: { type: integer }
        resolved_items: { type: integer }

example_output: |
  {
    "last_updated": "<date from source>",
    "quick_status": "<summary grounded in recorded evidence>",
    "summary_table": [
      { "layer": "<layer>", "tests_passing": null, "tests_total": null, "status": "🔄 In Progress" }
    ],
    "recent_updates": [],
    "technical_debt": { "open_items": null, "resolved_items": null }
  }
```

---

### 1.2 `pgmcp://status/phase` (Implemented)

**Description:** Read-time snapshot of the current Git branch, its persisted workflow
phase from `state.json`, working-tree cleanliness and read timestamp. The existing
branch-validated state reader refuses missing or mismatched state; no phase is
inferred from branch names and no GitHub Project query is made.

**Data Format:** JSON

**Refresh:** Recomputed when the resource is read.

```json
{
  "current_phase": "implementation",
  "active_branch": "feature/42-example",
  "is_clean": true,
  "last_updated": "2026-10-14 12:00:00"
}
```

`current_phase` is the stored configured phase identifier. Resource read failures
remain errors instead of returning an invented phase.

---

### 1.3 `pgmcp://github/issues` (Implemented)

**Description:** Comprehensive view of GitHub issues with filtering by state, labels, milestone, and project.

**Data Format:** `json`

**Refresh:** Read-time snapshot of open issues from the configured GitHub adapter; no polling TTL or webhook refresh is promised.

**Dependencies:** `GITHUB_TOKEN` environment variable

```yaml
schema:
  type: object
  properties:
    open_count: { type: integer }
    closed_count: { type: integer }
    issues:
      type: array
      items:
        type: object
        properties:
          number: { type: integer }
          title: { type: string }
          state: { type: string, enum: [open, closed] }
          labels:
            type: array
            items: { type: string }
          milestone:
            type: object
            properties:
              title: { type: string }
              due_on: { type: string, format: date }
          assignees:
            type: array
            items: { type: string }
          project_status:
            type: string
            enum: [Backlog, Todo, In Progress, In Review, Done]
            description: "Status from GitHub Project board"
          linked_pr:
            type: integer
            description: "PR number if issue is linked to a PR"
          created_at: { type: string, format: datetime }
          updated_at: { type: string, format: datetime }
          closed_at: { type: string, format: datetime }

example_output: |
  {
    "open_count": 12,
    "closed_count": 45,
    "issues": [
      {
        "number": 45,
        "title": "Implement WorkerManifest schema",
        "state": "open",
        "labels": ["type:feature", "phase:implementation", "priority:high"],
        "milestone": { "title": "Week 1: Config Schemas", "due_on": "2025-12-09" },
        "assignees": ["mikey"],
        "project_status": "In Progress",
        "linked_pr": null,
        "created_at": "2025-12-01T10:00:00Z",
        "updated_at": "2025-12-08T14:30:00Z"
      }
    ]
  }
```

---

### 1.4 `pgmcp://github/project` (Planned)

**Description:** GitHub Project board state including columns, items, and iteration tracking.

**Data Format:** `json`

**Refresh Trigger:** Polling (TTL: 120 seconds)

**Dependencies:** `GITHUB_TOKEN` environment variable with `project` scope

```yaml
schema:
  type: object
  properties:
    project_name: { type: string }
    project_url: { type: string }
    columns:
      type: array
      items:
        type: object
        properties:
          name: { type: string }
          count: { type: integer }
          items:
            type: array
            items:
              type: object
              properties:
                type: { type: string, enum: [Issue, PR, DraftIssue] }
                number: { type: integer }
                title: { type: string }
                assignee: { type: string }
    current_iteration:
      type: object
      properties:
        name: { type: string }
        start_date: { type: string, format: date }
        end_date: { type: string, format: date }
        completed_points: { type: integer }
        total_points: { type: integer }
    metrics:
      type: object
      properties:
        velocity: { type: number, description: "Average points per sprint" }
        burndown:
          type: array
          items:
            type: object
            properties:
              date: { type: string, format: date }
              remaining: { type: integer }

example_output: |
  {
    "project_name": "PhaseGate Development",
    "project_url": "https://github.com/users/example-user/projects/1",
    "columns": [
      { "name": "Backlog", "count": 8, "items": [...] },
      { "name": "Todo", "count": 3, "items": [...] },
      { "name": "In Progress", "count": 2, "items": [...] },
      { "name": "Done", "count": 15, "items": [...] }
    ],
    "current_iteration": {
      "name": "Sprint 3",
      "start_date": "2025-12-02",
      "end_date": "2025-12-16",
      "completed_points": 8,
      "total_points": 21
    }
  }
```

---

### 1.5 `pgmcp://git/status` (Planned)

**Description:** Current branch, uncommitted changes, staged files, and TDD phase.

**Data Format:** `json`

**Refresh Trigger:** Polling (5s)

```yaml
schema:
  type: object
  properties:
    branch: { type: string }
    is_clean: { type: boolean }
    staged_files: { type: array, items: { type: string } }
    modified_files: { type: array, items: { type: string } }
    untracked_files: { type: array, items: { type: string } }
    tdd_phase: { type: string, enum: [RED, GREEN, REFACTOR, UNKNOWN] }
```

### 1.6 `pgmcp://docs/inventory` (Planned)

**Description:** Inventory of all documentation files with compliance status.

**Data Format:** `json`

**Refresh Trigger:** Polling (300s)

```yaml
schema:
  type: object
  properties:
    documents:
      type: array
      items:
        type: object
        properties:
          path: { type: string }
          line_count: { type: integer }
          template_compliance: { type: boolean }
          broken_links: { type: integer }
```

### 1.7 `pgmcp://arch/violations` (Planned)

**Description:** Detected architecture anti-patterns and violations.

**Data Format:** `json`

**Refresh Trigger:** On save

```yaml
schema:
  type: object
  properties:
    violations:
      type: array
      items:
        type: object
        properties:
          file: { type: string }
          line: { type: integer }
          pattern: { type: string }
          message: { type: string }
          severity: { type: string, enum: [error, warning] }
```

---

### 1.8 `pgmcp://rules/coding_standards` (Implemented)

**Description:** Snapshot of the execution policies validated at target-server startup. The URI remains available for policy discovery; the full coding rules remain in `docs/coding_standards/`.

**Data Format:** JSON, `schema_version: 1`. The resource uses the same immutable `checks.yaml`, `tests.yaml`, and `fixes.yaml` models as the active tools. Changes to those files take effect after server restart. These fields describe configured policy, not observed results or a promised coverage score.

```json
{
  "schema_version": 1,
  "run_checks": {
    "default_profile": "<profile ID or null>",
    "profiles": {"<profile ID>": ["<check ID>"]},
    "bindings": {"<check ID>": {"adapter_id": "<adapter ID>", "capability": "<capability ID>"}}
  },
  "run_tests": {
    "bindings": {"<test ID>": {"adapter_id": "<adapter ID>", "capability": "<capability ID>", "active": true}}
  },
  "apply_fixes": {
    "bindings": {"<fix ID>": {"adapter_id": "<adapter ID>", "capability": "<capability ID>"}}
  }
}
```

The maps contain the configured IDs, including inactive test bindings. The response has no numbered quality gates, `active_gates`, or `coverage_min` field.


### 1.9 `pgmcp://cache/runs/{run_id}` (Implemented)

Each tool response that successfully publishes a result includes its run-specific cache URI.
A plain read returns the complete cached JSON result. For large results, use
`?offset=<codepoint-offset>&limit=<1-12000>` with both parameters present; pages report
the run ID, total codepoint length, SHA-256, text window, and next offset. Follow pages
contiguously and verify the same run ID, hash, and total length before parsing the
assembled JSON. If a window is truncated, retry that same offset with a smaller limit.
On cache loss or hash change, discard partial data. Repeat only a safe read-only query;
never rerun a mutation or other non-repeatable producer to recover its cached result.
See the packaged [cache-reading guide](../../mcp_server/resources/cache_reading.md) or the
`pgmcp://docs/cache-reading` resource for the full protocol.

### 1.10 `pgmcp://docs/cache-reading` (Implemented)

Serves the packaged cache-window guide, including limits, contiguous paging, integrity
verification, and safe retry rules. It is documentation, not a cached tool result.

---

### 1.11 `pgmcp://templates/list` (Planned)

**Description:** Provides the complete template hierarchy and guidance on when to use each template. Sourced from `docs/reference/templates/README.md`.

**Data Format:** `json`

**Refresh Trigger:** File watcher on `docs/reference/templates/`

```yaml
schema:
  type: object
  properties:
    hierarchy:
      type: object
      description: "Template inheritance tree"
      properties:
        base_template:
          type: object
          properties:
            path: { type: string }
            inherits_from: { type: null }
            used_for: { type: string }
        architecture_template:
          type: object
          properties:
            path: { type: string }
            inherits_from: { type: string, default: "BASE_TEMPLATE" }
            used_for: { type: string }
            location: { type: string }
            sections_numbered: { type: boolean }
        design_template:
          type: object
          properties:
            path: { type: string }
            inherits_from: { type: string, default: "BASE_TEMPLATE" }
            used_for: { type: string }
            location: { type: string }
            sections_numbered: { type: boolean }
        reference_template:
          type: object
          properties:
            path: { type: string }
            inherits_from: { type: string, default: "BASE_TEMPLATE" }
            used_for: { type: string }
            location: { type: string }
            sections_numbered: { type: boolean }
        tracking_template:
          type: object
          properties:
            path: { type: string }
            inherits_from: { type: null, description: "Does NOT inherit from BASE" }
            used_for: { type: string }
            location: { type: string }
    decision_tree:
      type: string
      description: "Mermaid flowchart or text decision tree for template selection"
    status_lifecycle:
      type: array
      items: { type: string }
      description: "DRAFT → PRELIMINARY → APPROVED → DEFINITIVE"

example_output: |
  {
    "hierarchy": {
      "base_template": { "path": "docs/reference/templates/BASE_TEMPLATE.md", "used_for": "Foundation structure" },
      "architecture_template": { "path": "docs/reference/templates/ARCHITECTURE_TEMPLATE.md", "inherits_from": "BASE_TEMPLATE", "used_for": "System design (docs/architecture/)", "sections_numbered": true },
      "design_template": { "path": "docs/reference/templates/DESIGN_TEMPLATE.md", "inherits_from": "BASE_TEMPLATE", "used_for": "Pre-implementation decisions (docs/development/)", "sections_numbered": true },
      "reference_template": { "path": "docs/reference/templates/REFERENCE_TEMPLATE.md", "inherits_from": "BASE_TEMPLATE", "used_for": "API & implementation docs (docs/reference/)", "sections_numbered": false },
      "tracking_template": { "path": "docs/reference/templates/TRACKING_TEMPLATE.md", "inherits_from": null, "used_for": "Progress tracking, TODOs (docs/, docs/implementation/)" }
    },
    "status_lifecycle": ["DRAFT", "PRELIMINARY", "APPROVED", "DEFINITIVE"]
  }
```
