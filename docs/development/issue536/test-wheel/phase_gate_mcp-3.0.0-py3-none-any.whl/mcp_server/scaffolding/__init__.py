"""Scaffolding package."""
