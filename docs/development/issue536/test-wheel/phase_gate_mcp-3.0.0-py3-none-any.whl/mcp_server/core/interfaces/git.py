# c:\temp\pgmcp\mcp_server\core\interfaces\git.py
# template=interface version=3fb28c28 created=2026-06-20T18:31:11Z updated=
"""IGitContextReader module.

Read-only git context for the current branch.

@layer: Backend (Contracts)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Protocol, runtime_checkable

from mcp_server.core.exceptions import ExecutionError


class BranchBasisUnavailableError(ExecutionError):
    """Raised when the configured branch basis cannot be observed."""

    def __init__(
        self,
        reason: Literal["parent_unavailable", "merge_base_unavailable"],
        message: str,
    ) -> None:
        super().__init__(message)
        self.reason: Literal["parent_unavailable", "merge_base_unavailable"] = reason
        self.message = message


@dataclass(frozen=True)
class BranchChanges:
    """Tracked and untracked paths introduced relative to a branch parent."""

    current_paths: tuple[str, ...]
    removed_paths: tuple[str, ...]


@runtime_checkable
class IBranchChangeReader(Protocol):
    """Read branch changes without exposing broader Git context operations."""

    def get_current_branch(self) -> str:
        raise NotImplementedError

    def get_branch_changes(self, parent: str) -> BranchChanges:
        raise NotImplementedError


@runtime_checkable
class IGitContextReader(Protocol):
    """Read-only git context for the current branch."""

    def get_current_branch(self) -> str:
        raise NotImplementedError

    def get_recent_commits(self, limit: int = 5) -> list[str]:
        raise NotImplementedError

    def get_status(self) -> dict[str, Any]:
        raise NotImplementedError


@runtime_checkable
class IBranchParentReader(Protocol):
    """Read the parent branch for a given branch from persisted state."""

    def get_parent_branch(self, branch: str) -> str | None:
        raise NotImplementedError


@dataclass(frozen=True)
class CommitRecord:
    """Opaque identity and subject from local Git traversal."""

    sha: str
    subject: str


@dataclass(frozen=True)
class CommitHistorySnapshot:
    """Issue-prefiltered metadata reachable from one captured branch HEAD."""

    branch: str
    head_sha: str
    shallow: bool
    records: tuple[CommitRecord, ...]


class CommitHistoryUnavailableError(ExecutionError):
    """Structured local history failure without inferred execution facts."""

    def __init__(
        self, reason_code: str, branch: str | None = None, head_sha: str | None = None
    ) -> None:
        super().__init__(reason_code)
        self.reason_code = reason_code
        self.branch = branch
        self.head_sha = head_sha


@dataclass(frozen=True)
class CycleEvidence:
    """Read-only execution evidence, including known positives under uncertainty."""

    status: Literal["complete", "unavailable"]
    branch: str | None
    head_sha: str | None
    execution_phase: str | None
    protected_cycle_numbers: tuple[int, ...]
    reason_code: str | None = None
    diagnostic_commit_sha: str | None = None


class ICycleEvidenceReader(Protocol):
    """Expose execution evidence without Git or planning mutation commands."""

    def read_cycle_evidence(
        self, issue_number: int, execution_phase: str | None
    ) -> CycleEvidence: ...
