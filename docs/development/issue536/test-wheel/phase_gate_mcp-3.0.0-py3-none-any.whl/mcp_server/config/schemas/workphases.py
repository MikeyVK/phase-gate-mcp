# mcp_server/config/schemas/workphases.py
"""
Workphase metadata schema definitions.

Defines typed value objects for phase display metadata, entry expectations,
and exit requirements loaded by the configuration layer.

@layer: Backend (Config)
@dependencies: [pydantic, typing]
@responsibilities:
    - Define phase metadata and root workphase schema contracts
    - Validate workphase metadata structure
    - Provide entry and exit requirement lookup helpers
"""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator

from mcp_server.config.ordering import ConfigId, OrderedConfigEntry, ordered_mapping
from mcp_server.core.scope_contract import validate_scope_vocabulary


class PhaseExpectation(OrderedConfigEntry):
    """Identified expectation with an existing state key and descriptive payload."""

    key: str
    description: str = ""


OrderedExpectations = Annotated[dict[ConfigId, PhaseExpectation], AfterValidator(ordered_mapping)]


class PhaseDefinition(BaseModel):
    """Single phase definition from workphases.yaml."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    display_name: str = ""
    description: str = ""
    commit_type_hint: str | None = None
    subphases: list[str] = Field(default_factory=list)
    exit_requires: OrderedExpectations = Field(default_factory=dict)
    entry_expects: OrderedExpectations = Field(default_factory=dict)
    terminal: bool = False


class WorkphasesConfig(BaseModel):
    """Read-only phase metadata value object."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["1.0.0"] = Field("1.0.0", description="Schema version")
    phases: dict[ConfigId, PhaseDefinition] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_single_terminal_phase(self) -> WorkphasesConfig:
        """Enforce exactly one terminal phase across all phases."""
        terminal = [name for name, phase in self.phases.items() if phase.terminal]
        if len(terminal) == 0:
            raise ValueError(
                "workphases.yaml must declare exactly one terminal phase. "
                "None found. Add 'terminal: true' to the intended phase."
            )
        if len(terminal) > 1:
            raise ValueError(
                f"workphases.yaml declares multiple terminal phases: {terminal}. "
                "Exactly one is permitted."
            )
        return self

    @model_validator(mode="after")
    def validate_commit_scope_vocabulary(self) -> WorkphasesConfig:
        """Reject names that cannot round-trip through the shared scope grammar."""
        validate_scope_vocabulary({name: phase.subphases for name, phase in self.phases.items()})
        return self

    def get_terminal_phase(self) -> str:
        """Return the name of the single terminal phase. Guaranteed by validator."""
        return next(name for name, phase in self.phases.items() if phase.terminal)

    def get_exit_requires(self, phase: str) -> list[dict[str, Any]]:
        phase_definition = self.phases.get(phase)
        return (
            [
                entry.model_dump(exclude={"order"})
                for entry in phase_definition.exit_requires.values()
            ]
            if phase_definition is not None
            else []
        )

    def get_entry_expects(self, phase: str) -> list[dict[str, Any]]:
        phase_definition = self.phases.get(phase)
        return (
            [
                entry.model_dump(exclude={"order"})
                for entry in phase_definition.entry_expects.values()
            ]
            if phase_definition is not None
            else []
        )
