# mcp_server/config/schemas/issue_config.py
"""
Issue configuration schema definitions.

Defines typed value objects for issue types, workflow mapping, and label
requirements loaded by the config layer.

@layer: Backend (Config)
@dependencies: [pydantic]
@responsibilities:
    - Define issue type and root issue config schema contracts
    - Validate issue workflow and label requirement metadata
    - Provide issue-type lookup helpers for workflow consumers
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from mcp_server.config.ordering import ConfigId


class IssueTypeEntry(BaseModel):
    """Single issue type entry from issues.yaml."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    workflow: str
    label: str


class IssueConfig(BaseModel):
    """Issue conventions configuration value object."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: Literal["1.0.0"] = Field("1.0.0", description="Schema version")
    issue_types: dict[ConfigId, IssueTypeEntry]
    required_label_categories: list[str] = Field(default_factory=list)
    optional_label_inputs: dict[str, Any] = Field(default_factory=dict)

    def get_workflow(self, issue_type: str) -> str:
        entry = self.issue_types.get(issue_type)
        if entry is None:
            valid = sorted(self.issue_types)
            raise ValueError(f"Unknown issue type: '{issue_type}'. Valid types: {valid}")
        return entry.workflow

    def get_label(self, issue_type: str) -> str:
        entry = self.issue_types.get(issue_type)
        if entry is None:
            valid = sorted(self.issue_types)
            raise ValueError(f"Unknown issue type: '{issue_type}'. Valid types: {valid}")
        return entry.label

    def has_issue_type(self, issue_type: str) -> bool:
        return issue_type in self.issue_types
