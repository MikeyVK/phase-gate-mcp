# mcp_server/config/schemas/enforcement_config.py
"""
Enforcement configuration schema definitions.

Defines typed value objects for pre and post-operation enforcement rules
loaded by the config layer.

@layer: Backend (Config)
@dependencies: [pydantic, typing]
@responsibilities:
    - Define enforcement rule and action schema contracts
    - Validate enforcement configuration structure
    - Represent policy hooks for runtime enforcement execution
"""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator

from mcp_server.config.ordering import ConfigId, OrderedConfigEntry, ordered_mapping


class EnforcementAction(OrderedConfigEntry):
    """One configured enforcement action."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    type: str
    policy: str | None = None
    rules: dict[str, list[str]] = Field(default_factory=dict)
    path: str | None = None
    message: str | None = None
    enabled: bool = True
    exempt_tools: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_required_fields(self) -> EnforcementAction:
        if self.type == "check_branch_policy" and not self.rules:
            raise ValueError("check_branch_policy requires non-empty rules")
        if self.type == "delete_file" and not self.path:
            raise ValueError("delete_file requires path")
        return self


class EnforcementRule(OrderedConfigEntry):
    """One configured enforcement rule."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    event_source: str
    timing: str
    tool: str | None = None
    tool_category: str | None = None
    phase: str | None = None
    actions: Annotated[dict[ConfigId, EnforcementAction], AfterValidator(ordered_mapping)] = Field(
        default_factory=dict
    )

    @model_validator(mode="after")
    def validate_target(self) -> EnforcementRule:
        if self.event_source == "tool":
            if self.tool and self.tool_category:
                raise ValueError("tool and tool_category are mutually exclusive")
            if not self.tool and not self.tool_category:
                raise ValueError("tool event_source requires tool or tool_category")
        if self.event_source == "phase" and not self.phase:
            raise ValueError("phase event_source requires phase")
        return self


class EnforcementConfig(BaseModel):
    """Typed root object for enforcement.yaml."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    version: Literal["1.0.0"] = Field("1.0.0", description="Config schema version")
    categories: dict[str, list[str]] = Field(default_factory=dict)
    enforcement: Annotated[dict[ConfigId, EnforcementRule], AfterValidator(ordered_mapping)] = (
        Field(default_factory=dict)
    )
