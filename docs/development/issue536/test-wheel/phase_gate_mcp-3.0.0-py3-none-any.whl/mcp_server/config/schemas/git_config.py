# mcp_server/config/schemas/git_config.py
"""
Git configuration schema value object.

Defines the typed contract for git conventions loaded from YAML by the
configuration layer.

@layer: Backend (Config)
@dependencies: [pydantic, re, typing]
@responsibilities:
    - Define the typed GitConfig schema contract
    - Validate cross-field git configuration consistency
    - Expose helper methods for branch and commit convention checks
"""

from __future__ import annotations

import re
from typing import ClassVar, Literal

from pydantic import BaseModel, Field, model_validator


class GitConfig(BaseModel):
    """Git conventions configuration value object."""

    version: Literal["1.0.0"] = Field(
        "1.0.0",
        description="Version of the git configuration schema",
    )
    branch_types: list[str] = Field(
        ...,
        description="Allowed branch types for create_branch()",
        min_length=1,
    )
    protected_branches: list[str] = Field(
        ...,
        description="Branches that cannot be deleted",
        min_length=1,
    )
    branch_name_pattern: str = Field(
        ...,
        description="Regex pattern for branch name validation (kebab-case default)",
    )
    commit_types: list[str] = Field(
        ...,
        description="Allowed Conventional Commit types",
        min_length=1,
    )
    issue_title_max_length: int = Field(
        ...,
        description="Maximum allowed length for issue titles",
        ge=1,
    )

    _compiled_pattern: ClassVar[re.Pattern[str] | None] = None

    @model_validator(mode="after")
    def validate_branch_name_pattern(self) -> GitConfig:
        pattern = str(self.branch_name_pattern)
        if not pattern or pattern.isspace():
            raise ValueError(
                "branch_name_pattern cannot be empty. "
                "Provide a valid regex pattern (e.g. '^[a-z0-9-]+$' for kebab-case)"
            )
        try:
            GitConfig._compiled_pattern = re.compile(pattern)
        except re.error as exc:
            raise ValueError(f"Invalid branch_name_pattern regex: {pattern}. Error: {exc}") from exc
        return self

    def has_branch_type(self, branch_type: str) -> bool:
        return branch_type in self.branch_types

    def validate_branch_name(self, name: str) -> bool:
        if GitConfig._compiled_pattern is None:
            GitConfig._compiled_pattern = re.compile(self.branch_name_pattern)
        return GitConfig._compiled_pattern.match(name) is not None

    def has_commit_type(self, commit_type: str) -> bool:
        return commit_type.lower() in self.commit_types

    def is_protected(self, branch_name: str) -> bool:
        return branch_name in self.protected_branches

    def get_all_prefixes(self) -> list[str]:
        return [f"{t}:" for t in self.commit_types]

    def build_branch_type_regex(self) -> str:
        return f"(?:{'|'.join(self.branch_types)})"

    def extract_issue_number(self, branch: str) -> int | None:
        pattern = rf"^(?:{self.build_branch_type_regex()[3:-1]})/(\d+)-"
        match = re.match(pattern, branch)
        if match is None:
            return None
        return int(match.group(1))

    def format_branch_name(self, issue_number: int, name: str, branch_type: str) -> str:
        """Format and validate a canonical branch name from components.

        Args:
            issue_number: GitHub issue number (must be >= 1).
            name: Branch name slug in kebab-case (leading issue prefix stripped if present).
            branch_type: Configured branch type (feature, bug, epic, etc.).

        Returns:
            Canonical full branch name (e.g. 'feature/116-create-branch-issue-number').

        Raises:
            ValueError: If issue_number < 1, branch_type is invalid, or slug fails pattern.
        """
        if issue_number < 1:
            raise ValueError(f"Invalid issue number: {issue_number}. Must be >= 1.")

        if not self.has_branch_type(branch_type):
            allowed = ", ".join(self.branch_types)
            raise ValueError(f"Invalid branch type: '{branch_type}'. Allowed types: {allowed}")

        slug = name.removeprefix(f"{issue_number}-")

        if not self.validate_branch_name(slug):
            raise ValueError(
                f"Invalid branch name slug: '{slug}'. "
                f"Must match pattern: {self.branch_name_pattern}"
            )

        return f"{branch_type}/{issue_number}-{slug}"

    def canonical_issue_marker(self, issue_number: int) -> str:
        """Return the exact subject suffix used for issue attribution."""
        if issue_number < 1:
            raise ValueError("issue_number_invalid")
        return f"(#{issue_number})"

    def subject_has_issue(self, subject: str, issue_number: int) -> bool:
        """Qualify one exact terminal subject marker, never a body or larger number."""
        marker = self.canonical_issue_marker(issue_number)
        return subject.endswith(f" {marker}")

    def normalize_issue_title(self, title: str, issue_number: int) -> str:
        """Remove matching standalone title markers before appending one canonical suffix."""
        self.canonical_issue_marker(issue_number)
        pattern = rf"\(#{issue_number}\)|(?<![\w#])#{issue_number}(?![\w])"
        without_markers = re.sub(pattern, "", title)
        return re.sub(r"[ \t]+", " ", without_markers).strip()
