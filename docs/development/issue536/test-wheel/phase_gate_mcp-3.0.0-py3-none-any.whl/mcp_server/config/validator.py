# mcp_server/config/validator.py
"""
Startup cross-config validation for MCP server composition root.

Validates relationships between already loaded configuration value objects
before the MCP server starts accepting requests.

@layer: Backend (Config)
@dependencies: [mcp_server.core.exceptions, mcp_server.schemas]
@responsibilities:
    - Validate contracts.yaml phase references against workphases catalog
    - Validate the merge-policy phase against the workphase catalog
"""

from __future__ import annotations

from typing import Protocol

from jsonschema import Draft202012Validator

from mcp_server.config.schemas.artifact_locations import ArtifactLocationsConfig
from mcp_server.config.schemas.checks_config import ChecksConfig
from mcp_server.config.schemas.contracts_config import ContractsConfig
from mcp_server.config.schemas.fixes_config import FixesConfig
from mcp_server.config.schemas.template_suite import TemplatePolicy
from mcp_server.config.schemas.tests_config import TestsConfig
from mcp_server.core.exceptions import ConfigError
from mcp_server.core.interfaces.execution import (
    CheckCatalogReader,
    FixCatalogReader,
    TestCatalogReader,
)
from mcp_server.core.interfaces.template_catalog import FrozenJsonObject, freeze_json, thaw_json
from mcp_server.schemas import (
    WorkflowConfig,
    WorkphasesConfig,
)


class _ContextSchemaValidator(Protocol):
    """Describe native JSON Schema validation without assuming its dynamic inputs."""

    def validate(self, instance: object) -> None: ...


def _validate_context_schema(
    validator: _ContextSchemaValidator, context: FrozenJsonObject
) -> FrozenJsonObject:
    validator.validate(thaw_json(context))
    return context


class ConfigValidator:
    """Validate cross-config relationships after ConfigLoader has loaded schemas."""

    def validate_template_context(
        self, schema: FrozenJsonObject, context: object
    ) -> FrozenJsonObject:
        """Validate the exposed snapshot and preserve caller presence and JSON types."""
        frozen = freeze_json(context)
        if not isinstance(frozen, FrozenJsonObject):
            raise ValueError("template_context_object_required")
        schema_data = {key: thaw_json(value) for key, value in schema.items()}
        return _validate_context_schema(Draft202012Validator(schema_data), frozen)

    def validate_template_policy(self, policy: TemplatePolicy, profiles: frozenset[str]) -> None:
        """Require a known output profile from the composition-supplied capability authority."""
        if policy.output_profile not in profiles:
            raise ConfigError("template_output_profile_unknown")

    def validate_checks_config(
        self,
        config: ChecksConfig,
        catalog: CheckCatalogReader,
        *,
        template_profiles: frozenset[str],
    ) -> None:
        """Validate declared references and consumer input support without execution."""
        checks = {
            check_id: catalog.get_check(binding.adapter_id, binding.capability)
            for check_id, binding in config.checks
        }
        policies = dict(config.configured_targets)
        for check_id, binding in checks.items():
            if "selection" in binding.capability.inputs:
                reference = binding.capability.configured_targets
                if reference not in policies:
                    raise ConfigError(
                        f"configured_targets_reference_unknown: {check_id}/{reference}"
                    )
        profiles = dict(config.profiles)
        content_profiles = template_profiles | frozenset(
            profile_id for _, profile_id in config.profiles_by_extension
        )
        default_profile = config.run_checks.default_profile
        selection_profiles = (
            frozenset({default_profile}) if default_profile is not None else frozenset[str]()
        )
        for input_kind, required_profiles in (
            ("content", content_profiles),
            ("selection", selection_profiles),
        ):
            for profile_id in sorted(required_profiles):
                if profile_id not in profiles:
                    raise ConfigError(f"check_profile_unknown: {profile_id}")
                for check_id in profiles[profile_id].checks:
                    if input_kind not in checks[check_id].capability.inputs:
                        raise ConfigError(
                            f"check_profile_input_unsupported: {profile_id}/{check_id}/{input_kind}"
                        )

    def validate_fixes_config(self, config: FixesConfig, catalog: FixCatalogReader) -> None:
        """Resolve each fix capability without requiring native availability or checks."""
        for _, binding in config.fixes:
            catalog.get_fix(binding.adapter_id, binding.capability)

    def validate_tests_config(self, config: TestsConfig, catalog: TestCatalogReader) -> None:
        """Resolve every declared test binding without invoking native tools."""
        for _, binding in config.tests:
            catalog.get_test(binding.adapter_id, binding.capability)

    def validate_artifact_locations(
        self, config: ArtifactLocationsConfig, template_ids: frozenset[str]
    ) -> None:
        """Require each configured location key to name one loaded template package."""
        unknown = sorted(set(dict(config.artifacts)) - template_ids)
        if unknown:
            raise ConfigError(f"artifact_location_template_unknown: {unknown}")

    def validate_startup(
        self,
        workflow: WorkflowConfig,
        contracts: ContractsConfig,
        workphases: WorkphasesConfig,
    ) -> None:
        """Validate startup relationships across already loaded config objects."""
        known_workflows = set(workflow.workflows)
        known_phases = set(workphases.phases)
        self._validate_phase_contracts(
            contracts=contracts,
            known_workflows=known_workflows,
            known_phases=known_phases,
        )
        self._validate_merge_policy_phase(
            contracts=contracts,
            known_phases=known_phases,
        )

    def _validate_phase_contracts(
        self,
        contracts: ContractsConfig,
        known_workflows: set[str],
        known_phases: set[str],
    ) -> None:
        for workflow_name, workflow_entry in contracts.workflows.items():
            if workflow_name not in known_workflows:
                raise ConfigError(f"contracts references unknown workflow: '{workflow_name}'")

            for phase_id in workflow_entry.phases:
                if phase_id not in known_phases:
                    raise ConfigError(
                        f"contracts reference phase '{phase_id}' "
                        "that is missing from workphases.yaml"
                    )

    def _validate_merge_policy_phase(
        self,
        contracts: ContractsConfig,
        known_phases: set[str],
    ) -> None:
        pr_phase = contracts.get_pr_allowed_phase()
        if pr_phase not in known_phases:
            raise ConfigError(
                f"merge_policy.pr_allowed_phase '{pr_phase}' is not a known workphase. "
                f"Known phases: {sorted(known_phases)}"
            )
