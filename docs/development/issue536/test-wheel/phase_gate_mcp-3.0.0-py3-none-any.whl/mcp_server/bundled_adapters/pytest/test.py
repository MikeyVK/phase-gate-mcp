"""Native Pytest test/v1 adapter; native options and results retain their meanings."""

from __future__ import annotations

import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, TypeGuard
from uuid import uuid4

if TYPE_CHECKING:
    import pytest

_KEYS = frozenset({"operation", "targets", "args", "execution_context"})
_ABSOLUTE_PATH = re.compile(r"^(?:/|[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/][^\\/]+)[\s\S]*$")


class _MetadataGuard:
    """Reject native metadata modes after Pytest has parsed all option sources."""

    def pytest_cmdline_main(self, config: pytest.Config) -> int | None:
        if config.option.help or config.option.version:
            sys.stderr.write("ERROR: Native metadata requests do not perform testing.\n")
            return 4
        return None


def _is_object_dict(value: object) -> TypeGuard[dict[object, object]]:
    return isinstance(value, dict)


def _is_object_list(value: object) -> TypeGuard[list[object]]:
    return isinstance(value, list)


def _invalid(location: list[str | int], code: str) -> dict[str, object]:
    return {"reason": "invalid_request", "details": [{"location": location, "code": code}]}


def _validate_execution_context(value: object) -> str | dict[str, object]:
    if not _is_object_dict(value):
        return _invalid(["execution_context"], "wrong_type")
    unknown = sorted(str(key) for key in set(value) - {"scratch_directory"})
    if unknown:
        return _invalid(["execution_context", unknown[0]], "unknown_field")
    if "scratch_directory" not in value:
        return _invalid(["execution_context", "scratch_directory"], "missing_field")
    directory = value["scratch_directory"]
    if not isinstance(directory, str):
        return _invalid(["execution_context", "scratch_directory"], "wrong_type")
    if not directory or "\x00" in directory or _ABSOLUTE_PATH.fullmatch(directory) is None:
        return _invalid(["execution_context", "scratch_directory"], "invalid_value")
    return directory


def _validate(
    value: object,
) -> tuple[tuple[str, ...], tuple[str, ...], Path] | dict[str, object]:
    if not _is_object_dict(value):
        return _invalid([], "wrong_type")
    unknown = sorted(str(key) for key in set(value) - _KEYS)
    missing = sorted(_KEYS - set(value))
    if unknown:
        return _invalid([unknown[0]], "unknown_field")
    if missing:
        return _invalid([missing[0]], "missing_field")
    scratch_directory = _validate_execution_context(value["execution_context"])
    if isinstance(scratch_directory, dict):
        return scratch_directory
    if not isinstance(value["operation"], str):
        return _invalid(["operation"], "wrong_type")
    if value["operation"] != "tests":
        return _invalid(["operation"], "invalid_value")
    targets: list[str] = []
    args: list[str] = []
    for field, admitted in (("targets", targets), ("args", args)):
        items = value[field]
        if not _is_object_list(items):
            return _invalid([field], "wrong_type")
        for index, item in enumerate(items):
            if not isinstance(item, str):
                return _invalid([field, index], "wrong_type")
            if field == "targets" and (
                not item or "\x00" in item or _ABSOLUTE_PATH.fullmatch(item) is None
            ):
                return _invalid([field, index], "invalid_value")
            admitted.append(item)
    return (
        tuple(targets),
        tuple(args),
        Path(scratch_directory),
    )


def _response(
    status: str,
    message: str,
    version: str | None,
    *,
    reason: str | None = None,
    evidence: str = "",
) -> tuple[dict[str, object], int]:
    decision = {"status": status, "message": message}
    if reason is not None:
        decision["reason"] = reason
    result: dict[str, object] = {
        "decision": decision,
        "external_tools": [{"tool_id": "pytest", "version": version}],
    }
    if evidence:
        result["evidence"] = {"format": "text", "data": evidence}
    return result, {"passed": 0, "failed": 1, "unavailable": 3}[status]


def _unavailable(
    reason: str,
    message: str,
    version: str | None = None,
    evidence: str = "",
) -> tuple[dict[str, object], int]:
    return _response("unavailable", message, version, reason=reason, evidence=evidence)


def _streams(result: subprocess.CompletedProcess[bytes]) -> tuple[str, str, str]:
    stdout = result.stdout.decode("utf-8", errors="replace")
    stderr = result.stderr.decode("utf-8", errors="replace")
    evidence = stdout
    if stderr:
        evidence = f"{stdout}\nstderr:\n{stderr}" if stdout else stderr
    return stdout, stderr, evidence


def _usage_reason(stderr: str) -> str:
    # Native 9.0.2 reports parse/config-loader failures with their actual source filename.
    if re.search(r"(?m)^ERROR: .+\.(?:toml|ini|cfg):", stderr) or stderr.startswith(
        "ImportError while loading conftest"
    ):
        return "invalid_configuration"
    if "ERROR: Missing required plugins:" in stderr:
        return "dependency_unavailable"
    return "unsupported_input"


def _run(value: object) -> tuple[dict[str, object], int]:
    validated = _validate(value)
    if isinstance(validated, dict):
        return validated, 2
    targets, args, scratch_directory = validated
    if any("\x00" in item for item in args):
        return _unavailable("unsupported_input", "Native arguments may not contain NUL.")
    if any(item in {"-h", "--help", "-V", "--version"} for item in args):
        return _unavailable("unsupported_input", "Native metadata requests do not perform testing.")
    if any("::" in target for target in targets):
        return _unavailable(
            "unsupported_input", "Pytest cannot represent this literal filesystem target."
        )
    if importlib.util.find_spec("pytest") is None:
        return _unavailable(
            "dependency_unavailable", "Pytest is unavailable to the adapter interpreter."
        )
    try:
        version_run = subprocess.run(
            [sys.executable, "-m", "pytest", "--version"],
            capture_output=True,
            check=False,
        )
    except OSError as exc:
        return _unavailable("dependency_unavailable", f"Pytest version lookup failed: {exc}")
    version_stdout, _, version_evidence = _streams(version_run)
    match = re.fullmatch(r"pytest ([^\r\n]+)\s*", version_stdout)
    if version_run.returncode != 0 or match is None:
        return _unavailable(
            "dependency_unavailable",
            "Pytest did not report a usable version.",
            evidence=version_evidence,
        )
    version = match[1]
    declaration = Path(__file__).with_name("requirements.txt")
    try:
        pins = re.findall(
            r"(?m)^pytest==([^\s;#]+)\s*(?:#.*)?$", declaration.read_text(encoding="utf-8")
        )
    except (OSError, UnicodeError) as exc:
        return _unavailable(
            "dependency_unavailable",
            f"Pytest dependency declaration could not be read: {declaration}: {exc}",
            version,
        )
    if len(pins) != 1:
        return _unavailable(
            "dependency_unavailable",
            f"Pytest dependency declaration requires one exact main-tool pin: {declaration}",
            version,
        )
    expected_version = pins[0]
    if version != expected_version:
        return _unavailable(
            "dependency_unavailable",
            f"Pytest version is unsupported: observed={version}, expected={expected_version}.",
            version,
        )
    arguments = (*targets, *args)
    if any(
        any(char in token for char in "\r\n\v\f\x1c\x1d\x1e\x85\u2028\u2029") for token in arguments
    ):
        return _unavailable(
            "unsupported_input",
            "Pytest argument-file tokens may not contain line separators.",
            version,
        )
    try:
        encoded_arguments = "".join(token + "\n" for token in arguments).encode("utf-8")
    except UnicodeError as exc:
        return _unavailable(
            "unsupported_input",
            f"Pytest argument-file tokens are not representable in UTF-8: {exc}",
            version,
        )
    argument_file = scratch_directory / f"pytest-{uuid4()}.args"
    try:
        with argument_file.open("xb") as stream:
            stream.write(encoded_arguments)
    except OSError as exc:
        return _unavailable(
            "execution_error",
            f"Pytest argument-file preparation failed: {argument_file}: {exc}",
            version,
        )
    try:
        result = subprocess.run(
            [sys.executable, __file__, "--native", f"@{argument_file}"],
            capture_output=True,
            check=False,
        )
    except OSError as exc:
        return _unavailable("execution_error", f"Pytest execution failed: {exc}", version)
    _, stderr, evidence = _streams(result)
    if result.returncode == 0:
        return _response(
            "passed",
            "Pytest completed the requested native operation (exit 0).",
            version,
            evidence=evidence,
        )
    if result.returncode == 5:
        return _response(
            "passed", "Pytest found no tests (native exit 5).", version, evidence=evidence
        )
    if result.returncode == 1:
        if not evidence.strip():
            return _unavailable(
                "invalid_result", "Pytest returned no negative-result evidence.", version
            )
        return _response(
            "failed",
            "Pytest reported a negative native result (exit 1).",
            version,
            evidence=evidence,
        )
    if result.returncode == 4:
        return _unavailable(
            _usage_reason(stderr), "Pytest rejected the native request (exit 4).", version, evidence
        )
    return _unavailable(
        "execution_error",
        f"Pytest could not complete the native request (exit {result.returncode}).",
        version,
        evidence,
    )


def main() -> int:
    try:
        request: object = json.loads(sys.stdin.buffer.read().decode("utf-8"))
    except UnicodeDecodeError, json.JSONDecodeError:
        response, exit_code = _invalid([], "invalid_value"), 2
    else:
        response, exit_code = _run(request)
    sys.stdout.buffer.write(json.dumps(response, ensure_ascii=False).encode("utf-8") + b"\n")
    return exit_code


if __name__ == "__main__":
    if sys.argv[1:2] == ["--native"]:
        # Preserve python -m pytest workspace imports in a fresh native interpreter.
        sys.path[0] = os.getcwd()
        import pytest

        pytest.hookimpl(tryfirst=True)(_MetadataGuard.pytest_cmdline_main)
        raise SystemExit(pytest.main(sys.argv[2:], plugins=[_MetadataGuard()]))
    raise SystemExit(main())
