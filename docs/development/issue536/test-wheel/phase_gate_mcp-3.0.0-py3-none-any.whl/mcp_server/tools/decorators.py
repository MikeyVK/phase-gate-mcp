"""ResourcePublishingDecorator module (empty, retired)."""
