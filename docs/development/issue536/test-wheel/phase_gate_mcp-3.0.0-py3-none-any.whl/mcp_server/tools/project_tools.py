"""Project management tools for MCP server.

Phase 0.5: Project initialization with workflow selection.
Issue #39: Project and branch-state initialization.
Explicit parent registration from the actual attached worktree branch.
Issue #229 Cycle 4: SavePlanningDeliverablesTool with Layer 2 validates schema validation.
"""

from pathlib import Path
from typing import Any, ClassVar

import anyio
from pydantic import BaseModel, ConfigDict, Field

from mcp_server.core.interfaces import ICoreTool
from mcp_server.core.interfaces.project_plan import IProjectPlanReader
from mcp_server.core.operation_notes import Note, NoteContext
from mcp_server.managers.git_manager import GitManager
from mcp_server.managers.phase_state_engine import PhaseStateEngine
from mcp_server.managers.project_manager import ProjectInitOptions, ProjectManager
from mcp_server.schemas import ContractsConfig
from mcp_server.schemas.deliverables import (
    PlanningOperation,
    SavePlanningModel,
    StoredPlanningModel,
)
from mcp_server.schemas.tool_outputs import (
    InitializeProjectOutput,
    PhaseDTO,
    PlannedCycleSummary,
    PlanningDeliverablesOutput,
    ProjectPlanOutput,
)
from mcp_server.utils.schema_utils import resolve_schema_refs


class InitializeProjectInput(BaseModel):
    """Input for initialize_project tool."""

    model_config = ConfigDict(extra="forbid")

    issue_number: int = Field(..., description="GitHub issue number")
    issue_title: str = Field(..., description="Issue title")
    workflow_name: str = Field(
        ...,
        description="Workflow name; valid values are injected from contracts.yaml",
    )
    parent_branch: str = Field(
        ...,
        min_length=1,
        pattern=r"^\S+$",
        description="Explicit parent branch for this registration; no inference or normalization.",
    )
    custom_phases: tuple[str, ...] | None = Field(
        default=None,
        description="Optional phase sequence override for the selected configured workflow",
    )
    skip_reason: str | None = Field(
        default=None,
        description="Required justification when custom_phases overrides the configured sequence",
    )


class InitializeProjectTool(ICoreTool[InitializeProjectInput, InitializeProjectOutput]):
    """Initialize project metadata and branch state after same-branch admission.

    Project and state writes remain separate; this guard prevents overwriting
    an already initialized branch before project persistence starts.
    """

    output_model: ClassVar[type[BaseModel]] = InitializeProjectOutput

    @property
    def name(self) -> str:
        return "initialize_project"

    @property
    def description(self) -> str:
        return (
            "Initialize a project with a configured workflow and optional justified "
            "phase-sequence override."
        )

    @property
    def args_model(self) -> type[BaseModel]:
        return InitializeProjectInput

    def __init__(
        self,
        workspace_root: Path | str,
        manager: ProjectManager,
        git_manager: GitManager,
        state_engine: PhaseStateEngine,
        contracts_config: ContractsConfig | None = None,
    ) -> None:
        """Initialize tool with injected project dependencies."""
        self.workspace_root = Path(workspace_root)
        self.manager = manager
        self.git_manager = git_manager
        self.state_engine = state_engine
        self._contracts_config = contracts_config

    @property
    def input_schema(self) -> dict[str, Any]:
        schema = resolve_schema_refs(self.args_model.model_json_schema())
        if self._contracts_config is not None:
            schema["properties"]["workflow_name"]["enum"] = list(
                self._contracts_config.workflows.keys()
            )
        return schema

    async def execute(
        self,
        params: InitializeProjectInput,
        context: NoteContext,
    ) -> InitializeProjectOutput:
        """Admit the branch, then initialize project metadata and branch state.

        Project and state are persisted separately.

        Args:
            params: InitializeProjectInput with issue details

        Returns:
            InitializeProjectOutput
        """
        del context
        # Step 0: Get current branch once and reuse
        with anyio.fail_after(5):
            branch = await anyio.to_thread.run_sync(self.git_manager.require_attached_branch)

        await anyio.to_thread.run_sync(
            lambda: self.state_engine.validate_branch_initialization(
                branch, params.issue_number, params.parent_branch
            )
        )

        options = ProjectInitOptions(
            custom_phases=params.custom_phases,
            skip_reason=params.skip_reason,
        )

        with anyio.fail_after(20):
            result = await anyio.to_thread.run_sync(
                lambda: self.manager.initialize_project(
                    issue_number=params.issue_number,
                    issue_title=params.issue_title,
                    workflow_name=params.workflow_name,
                    parent_branch=params.parent_branch,
                    options=options,
                )
            )

        # Step 3: Determine first phase from workflow
        first_phase = result["required_phases"][0]

        # Step 5: Initialize branch state
        with anyio.fail_after(10):
            await anyio.to_thread.run_sync(
                lambda: self.state_engine.initialize_branch(
                    branch=branch,
                    issue_number=params.issue_number,
                    initial_phase=first_phase,
                    parent_branch=params.parent_branch,
                )
            )

        return InitializeProjectOutput(
            success=True,
            issue_number=params.issue_number,
            workflow_name=params.workflow_name,
            branch=branch,
            initial_phase=first_phase,
            parent_branch=params.parent_branch,
            required_phases=result["required_phases"],
            execution_mode=result["execution_mode"],
            files_created=[
                "deliverables.json (workflow definition)",
                "state.json (branch state)",
            ],
        )


class GetProjectPlanInput(BaseModel):
    """Input for get_project_plan tool."""

    model_config = ConfigDict(extra="forbid")

    issue_number: int = Field(..., description="GitHub issue number")


class GetProjectPlanTool(ICoreTool[GetProjectPlanInput, ProjectPlanOutput]):
    """Tool for retrieving project plan."""

    output_model: ClassVar[type[BaseModel]] = ProjectPlanOutput

    @property
    def name(self) -> str:
        return "get_project_plan"

    @property
    def description(self) -> str:
        return "Get project phases and complete stored planning deliverables for an issue"

    @property
    def args_model(self) -> type[BaseModel]:
        return GetProjectPlanInput

    @property
    def input_schema(self) -> dict[str, Any]:
        return resolve_schema_refs(self.args_model.model_json_schema())

    def __init__(self, manager: IProjectPlanReader) -> None:
        """Initialize tool with the read-only project plan contract."""
        self.manager = manager

    async def execute(
        self,
        params: GetProjectPlanInput,
        context: NoteContext,
    ) -> ProjectPlanOutput:
        """Execute project plan retrieval.

        Args:
            params: GetProjectPlanInput with issue_number
            context: Call context
        """
        try:
            plan = self.manager.get_project_plan(issue_number=params.issue_number)
            if plan:
                required_phases = plan.get("required_phases", [])
                current_phase = plan.get("current_phase", "")
                curr_phase_name = current_phase.split(":")[0] if current_phase else ""

                phases_list: list[PhaseDTO] = []
                current_found = False
                for p_name in required_phases:
                    if p_name == curr_phase_name:
                        status = "active"
                        current_found = True
                    elif current_found:
                        status = "pending"
                    else:
                        status = "completed" if curr_phase_name else "pending"
                    phases_list.append(PhaseDTO(name=p_name, status=status, tasks=[]))

                stored_planning = plan.get("planning_deliverables")
                planning = (
                    StoredPlanningModel.model_validate(stored_planning, strict=True)
                    if stored_planning is not None
                    else None
                )
                return ProjectPlanOutput(
                    success=True,
                    issue_number=params.issue_number,
                    workflow_name=plan.get("workflow_name", ""),
                    phases=phases_list,
                    planning_deliverables=planning,
                )

            context.produce(
                Note(
                    key="initialize_project_suggestion",
                    params={
                        "issue_number": params.issue_number,
                    },
                )
            )
            return ProjectPlanOutput(
                success=False,
                error_message=f"No project plan found for issue #{params.issue_number}",
                issue_number=params.issue_number,
                workflow_name="",
                phases=[],
            )
        except (ValueError, OSError) as e:
            return ProjectPlanOutput(
                success=False,
                error_message=str(e),
                issue_number=params.issue_number,
                workflow_name="",
                phases=[],
            )


# ---------------------------------------------------------------------------
# Planning deliverables tools
# ---------------------------------------------------------------------------


class SavePlanningDeliverablesInput(BaseModel):
    """Create the complete initial plan; names and order determine stored references."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    issue_number: int = Field(gt=0, strict=True, description="GitHub issue number")
    planning_deliverables: SavePlanningModel


class UpdatePlanningDeliverablesInput(BaseModel):
    """Mutate complete blocks by original-snapshot references; omission leaves blocks unchanged."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    issue_number: int = Field(gt=0, strict=True, description="GitHub issue number")
    operations: list[PlanningOperation] = Field(
        min_length=1,
        description=(
            "Replace/remove original C_n cycles or named phase blocks explicitly. "
            "Cycles with qualifying execution commits cannot be replaced or removed. "
            "Append cycles after surviving originals in request order. "
            "All targets resolve before renumbering; duplicate targets reject the whole request."
        ),
    )
    force: bool = Field(
        default=False,
        strict=True,
        description=(
            "Retry local Git evidence and accept continued uncertainty after investigation. "
            "Known commit-protected replacement/deletion/renumbering "
            "and invalid planning remain forbidden."
        ),
    )


def _planning_input_schema(model: type[BaseModel], manager: ProjectManager) -> dict[str, Any]:
    """Expose the same configured phase vocabulary and omission semantics as admission."""
    schema = resolve_schema_refs(model.model_json_schema())
    properties = schema["properties"]
    config = manager.workphases_config
    phases = list(config.phases) if config is not None else []
    if "planning_deliverables" in properties:
        planning = properties["planning_deliverables"]["properties"]
        cycles = planning["cycles"]
        planning["cycles"] = next(
            option for option in cycles["anyOf"] if option.get("type") != "null"
        )
        planning["phases"]["propertyNames"] = {"enum": phases}
    if "operations" in properties:
        variants = properties["operations"]["items"]["oneOf"]
        for variant in variants:
            phase = variant["properties"].get("phase")
            if phase is not None:
                phase["enum"] = phases
    return schema


def _planning_response(
    planning: StoredPlanningModel, issue_number: int
) -> PlanningDeliverablesOutput:
    """Assemble one successful command response from the persisted complete plan."""
    cycles = planning.cycles.cycles if planning.cycles is not None else []
    summaries = [
        PlannedCycleSummary(
            cycle_id=cycle.cycle_id,
            cycle_number=cycle.cycle_number,
            cycle_name=cycle.cycle_name,
            deliverables_count=len(cycle.deliverables),
        )
        for cycle in cycles
    ]
    return PlanningDeliverablesOutput(
        success=True,
        issue_number=issue_number,
        total_cycles=len(cycles),
        total_deliverables=(
            sum(len(cycle.deliverables) for cycle in cycles)
            + sum(len(block.deliverables) for block in planning.phases.values())
        ),
        cycles=summaries,
        planning_deliverables=planning,
    )


class SavePlanningDeliverablesTool(
    ICoreTool[SavePlanningDeliverablesInput, PlanningDeliverablesOutput]
):
    """Create an initial complete plan once under configured Planning admission."""

    output_model: ClassVar[type[BaseModel]] = PlanningDeliverablesOutput

    def __init__(self, manager: ProjectManager, workspace_root: Path | str | None = None) -> None:
        del workspace_root
        self._manager = manager

    @property
    def name(self) -> str:
        return "save_planning_deliverables"

    @property
    def description(self) -> str:
        return (
            "Create the complete initial plan once. Supply cycle/deliverable names and ordered "
            "complete blocks; the server stores C_n, D_n.m and phase-local D_n references "
            "and totals."
        )

    @property
    def args_model(self) -> type[BaseModel]:
        return SavePlanningDeliverablesInput

    @property
    def input_schema(self) -> dict[str, Any]:
        return _planning_input_schema(SavePlanningDeliverablesInput, self._manager)

    async def execute(
        self, params: SavePlanningDeliverablesInput, context: NoteContext
    ) -> PlanningDeliverablesOutput:
        del context
        planning = self._manager.save_planning_deliverables(
            issue_number=params.issue_number,
            planning_deliverables=params.planning_deliverables,
        )
        return _planning_response(planning, params.issue_number)


class UpdatePlanningDeliverablesTool(
    ICoreTool[UpdatePlanningDeliverablesInput, PlanningDeliverablesOutput]
):
    """Apply explicit complete-block operations with fresh local execution evidence."""

    output_model: ClassVar[type[BaseModel]] = PlanningDeliverablesOutput

    def __init__(self, manager: ProjectManager, workspace_root: Path | str | None = None) -> None:
        del workspace_root
        self._manager = manager

    @property
    def name(self) -> str:
        return "update_planning_deliverables"

    @property
    def description(self) -> str:
        return (
            "Mutate an existing plan using append_cycle, replace_cycle, remove_cycle, "
            "set_phase or remove_phase. Targets refer to the original snapshot; complete "
            "blocks replace their contents. The server derives references and totals, "
            "protects committed cycles from replacement/deletion/renumbering, "
            "and retries evidence on every call."
        )

    @property
    def args_model(self) -> type[BaseModel]:
        return UpdatePlanningDeliverablesInput

    @property
    def input_schema(self) -> dict[str, Any]:
        return _planning_input_schema(UpdatePlanningDeliverablesInput, self._manager)

    async def execute(
        self, params: UpdatePlanningDeliverablesInput, context: NoteContext
    ) -> PlanningDeliverablesOutput:
        planning = self._manager.update_planning_deliverables(
            issue_number=params.issue_number,
            operations=params.operations,
            context=context,
            force=params.force,
        )
        return _planning_response(planning, params.issue_number)
