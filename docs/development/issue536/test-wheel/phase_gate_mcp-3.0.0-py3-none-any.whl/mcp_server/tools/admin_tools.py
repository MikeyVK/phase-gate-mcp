"""Administrative tools for server management.

Development tools for agent-driven workflows. Enables agents to:
- Restart server to load code changes
- Verify restart occurred
- Maintain audit trail of server lifecycle events
"""

import asyncio
import json
import logging
import os
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field, JsonValue

from mcp_server.core.interfaces import ICoreTool
from mcp_server.core.logging import get_logger, logging_extra
from mcp_server.core.operation_notes import NoteContext
from mcp_server.schemas.tool_outputs import RestartServerOutput

# Helper functions (module-level marker path helper removed — now an instance method)


def _create_audit_props(
    reason: str,
    event_type: str,
    **extra_props: JsonValue,
) -> dict[str, JsonValue]:
    """Create structured props for audit logging.

    Args:
        reason: Restart reason
        event_type: Type of restart event
        **extra_props: Additional properties to include

    Returns:
        Dictionary with standard audit props
    """
    props: dict[str, JsonValue] = {
        "reason": reason,
        "pid": os.getpid(),
        "event_timestamp": datetime.now(UTC).isoformat(),
        "event_type": event_type,
    }
    props.update(extra_props)
    return props


def _parse_marker_file(marker_path: Path) -> dict[str, Any]:
    """Parse restart marker file.

    Args:
        marker_path: Path to marker file

    Returns:
        Dictionary with marker data

    Raises:
        OSError: If file cannot be read
        json.JSONDecodeError: If JSON is invalid
    """
    with marker_path.open(encoding="utf-8") as f:
        marker_data: dict[str, Any] = json.load(f)
        return marker_data


class RestartServerInput(BaseModel):
    """Input for RestartServerTool."""

    model_config = ConfigDict(extra="forbid")

    reason: str = Field(
        default="code changes",
        description="Description of why restart is needed (for audit logging)",
    )


class RestartServerTool(ICoreTool[RestartServerInput, RestartServerOutput]):
    """Tool to restart MCP server to reload code changes.

    **Purpose:** Enable agent autonomy during TDD workflows.

    Agent can implement code changes and restart server without human
    intervention, allowing fully autonomous test-driven development cycles.
    """

    output_model: ClassVar[type[BaseModel]] = RestartServerOutput

    @property
    def name(self) -> str:
        return "restart_server"

    @property
    def description(self) -> str:
        return "Restart MCP server to reload code changes"

    @property
    def args_model(self) -> type[BaseModel]:
        return RestartServerInput

    def __init__(self, server_root: Path) -> None:
        """Initialize with the injected server_root directory."""
        self._server_root = server_root

    def _get_restart_marker_path(self) -> Path:
        """Return the restart marker path under the injected server_root."""
        return self._server_root / ".restart_marker"

    @property
    def input_schema(self) -> dict[str, Any]:
        """Return the input schema for the tool."""
        return self.args_model.model_json_schema()

    async def execute(
        self, params: RestartServerInput, context: NoteContext
    ) -> RestartServerOutput:
        """Execute server restart.

        **Workflow:**
        1. Agent makes code changes (via safe_edit_file)
        2. Agent calls restart_server(reason="...")
        3. Server logs restart to audit trail
        4. Server writes restart marker file
        5. Server returns success response
        6. Server schedules exit with code 42 (delayed)
        7. Parent process (VS Code) detects exit and restarts server
        8. Client observes the new server session after the supervisor restarts it
        9. Agent continues with testing/next cycle

        Args:
            params: RestartServerInput with reason field

        Returns:
            ToolResult with success message before server exits.

        Note:
            - Development tool only, not for production use
            - Parent process must handle exit code 42 by restarting server
            - All audit logs flushed before exit (zero data loss)
            - Restart marker written to .restart_marker in the state root
            - Server exits 500ms after returning response (graceful)
        """
        del context  # Not used by restart tool
        logger = get_logger("tools.admin")
        restart_time = datetime.now(UTC)
        logger.info(
            "Server restart requested",
            extra=logging_extra(
                _create_audit_props(
                    reason=params.reason,
                    event_type="server_restart_requested",
                )
            ),
        )

        # Write restart marker file (for verification)
        marker_path = self._get_restart_marker_path()
        marker_path.parent.mkdir(exist_ok=True)
        marker_content: dict[str, JsonValue] = {
            "timestamp": restart_time.timestamp(),
            "pid": os.getpid(),
            "reason": params.reason,
            "iso_time": restart_time.isoformat(),
        }

        marker_path.write_text(json.dumps(marker_content, indent=2), encoding="utf-8")

        # Audit log: Marker written
        logger.info(
            "Restart marker written",
            extra=logging_extra(
                _create_audit_props(
                    reason=params.reason,
                    event_type="restart_marker_written",
                    marker_path=str(marker_path),
                    marker_content=marker_content,
                )
            ),
        )

        # Schedule delayed exit in background (supervisor will restart)
        async def delayed_exit() -> None:
            """Exit with code 42 after short delay to allow response to be sent.

            The watchdog supervisor detects exit code 42 as a restart request
            and will spawn a new MCP server instance while maintaining the
            stdio connection to VS Code (no re-initialization needed).
            """
            await asyncio.sleep(0.1)  # 100ms delay - allow response to be sent

            # Flush all output (ensure audit logs persisted)
            sys.stdout.flush()
            sys.stderr.flush()

            # Force flush logging handlers
            for handler in logging.root.handlers:
                handler.flush()

            # Audit log: Exiting for restart
            logger.info(
                "Server exiting for restart (supervisor will spawn new instance)",
                extra=logging_extra(
                    _create_audit_props(
                        reason=params.reason,
                        event_type="server_exiting_for_restart",
                        exit_code=42,
                    )
                ),
            )

            # Final flush
            sys.stdout.flush()
            sys.stderr.flush()

            # Signal proxy to restart by printing marker
            print("__MCP_RESTART_REQUEST__", file=sys.stderr, flush=True)  # noqa: T201 - proxy protocol marker
            sys.stdout.flush()

            # Exit with code 42 (legacy supervisor support)
            # Note: Proxy intercepts marker above, exit code ignored
            sys.exit(42)

        # Start background exit task (fire-and-forget)
        asyncio.create_task(delayed_exit())

        return RestartServerOutput(
            success=True,
            reason=params.reason,
            pid=os.getpid(),
            timestamp=restart_time.timestamp(),
            iso_time=restart_time.isoformat(),
        )


# Convenience function for backward compatibility and testing
def restart_server(server_root: Path, reason: str = "code changes") -> None:
    """Restart MCP server (convenience function).

    This is a simple wrapper around RestartServerTool for easier testing.
    In production, use the tool via MCP protocol.

    Args:
        server_root: Path to the server root directory (contains state.json etc.).
        reason: Description of why restart is needed
    """
    tool = RestartServerTool(server_root=server_root)
    params = RestartServerInput(reason=reason)
    asyncio.run(tool.execute(params, NoteContext()))


def verify_server_restarted(
    since_timestamp: float, server_root: Path | None = None
) -> dict[str, Any]:
    """Inspect the restart marker after ``since_timestamp`` from Python.

    This internal helper is not registered as an MCP tool. It reports marker
    observations; a caller must separately observe the new server session.
    Pass ``server_root`` explicitly or provide ``PGMCP_CONFIG_ROOT``.
    """
    logger = get_logger("tools.admin")

    if server_root is not None:
        marker_path = server_root / ".restart_marker"
    else:
        config_root_env = os.environ.get("PGMCP_CONFIG_ROOT")
        if config_root_env:
            marker_path = Path(config_root_env).resolve().parent / ".restart_marker"
        else:
            raise ValueError(
                "verify_server_restarted requires server_root or PGMCP_CONFIG_ROOT env var"
            )

    # Check if marker exists
    if not marker_path.exists():
        return {
            "restarted": False,
            "error": "Restart marker not found",
            "marker_path": str(marker_path),
        }

    # Parse marker
    try:
        marker_data = _parse_marker_file(marker_path)
    except (OSError, json.JSONDecodeError) as e:
        return {
            "restarted": False,
            "error": f"Failed to parse restart marker: {e}",
        }

    restart_timestamp = marker_data["timestamp"]

    # Check if restart happened after since_timestamp
    restarted = restart_timestamp > since_timestamp

    result = {
        "restarted": restarted,
        "restart_timestamp": restart_timestamp,
        "current_pid": os.getpid(),
        "previous_pid": marker_data["pid"],
        "reason": marker_data["reason"],
        "time_since_restart": time.time() - restart_timestamp,
        "iso_time": marker_data["iso_time"],
    }

    # Audit log verification
    logger.info(
        "Server restart verification",
        extra=logging_extra(
            {
                "result": result,
                "since_timestamp": since_timestamp,
            }
        ),
    )

    return result
